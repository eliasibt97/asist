
<?php $__env->startSection('main'); ?>
    <h1>Información de responsable <?php echo e($responsable->name); ?></h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\elias\Documents\Projects\asist\resources\views/responsables/responsable-detalles.blade.php ENDPATH**/ ?>


<?php $__env->startSection('main'); ?>
    <div class="container">
        <table class="table">
            <thead>
            <tr>
                <th scope="col">N°</th>
                <th scope="col">Nombre</th>
                <th scope="col">Teéfono celular</th>
                <th scope="col">Correo</th>
                <th scope="col">Opciones</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $responsables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $responsable): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($responsable->id); ?></th>
                <td><?php echo e($responsable->name); ?></td>
                <td><?php echo e($responsable->cellphone); ?></td>
                <td><?php echo e($responsable->email); ?></td>
                <td>Editar..</td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\elias\Documents\Projects\asist\resources\views/responsables.blade.php ENDPATH**/ ?>
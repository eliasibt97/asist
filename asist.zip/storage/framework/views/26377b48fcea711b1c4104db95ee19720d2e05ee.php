

<?php $__env->startSection('main'); ?>
    <div class="main">
        <h3>Responsables</h3>
        <hr>
        <div class="row">
            <div class="col-sm-6">
                <div class="accordion accordion-flush" id="accordionFlushExample">
                    
                    <?php $__currentLoopData = $responsables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $responsable): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="flush-headingOne">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-<?php echo e($responsable->id); ?>" aria-expanded="false" aria-controls="flush-collapseOne">
                                <?php echo e($responsable->name); ?>

                            </button>
                        </h2>
                        <div id="flush-<?php echo e($responsable->id); ?>" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
                            <div class="accordion-body">
                                <p><strong>Teléfono celular:</strong> <?php echo e($responsable->cellphone); ?> </p>
                                <p><strong>Correo Electrónico:</strong> <?php echo e($responsable->email ?? 'No disponible'); ?>  </p>
                                <?php if(count($responsable->members) > 0): ?>
                                <p><strong>Responsable de:</strong> </p>
                                <ul>
                                    <?php $__currentLoopData = $responsable->members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($member->name); ?> <?php echo e($member->surnames); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                                <?php else: ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
            <div class="col-sm-6 resposables-data">
                <?php echo $__env->yieldContent('responsable'); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\elias\OneDrive\Documentos\Projects\asist\resources\views/responsables/responsables.blade.php ENDPATH**/ ?>
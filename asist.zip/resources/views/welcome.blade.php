@extends('layout')

@section('main')
    <h1> main </h1>
@endsection